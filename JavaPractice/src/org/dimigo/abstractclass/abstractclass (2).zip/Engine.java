package org.dimigo.abstractclass;

public abstract class Engine {
    public abstract void startEngine();
    public abstract void stopEngine();
}
